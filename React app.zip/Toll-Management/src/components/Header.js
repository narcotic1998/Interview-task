import '../styles/header.css'
const Header = ()=>{
    return(
        <header>
            <h6 className="heading">Toll Management Application</h6>
            <hr/>
        </header>
    )
}
export default Header;