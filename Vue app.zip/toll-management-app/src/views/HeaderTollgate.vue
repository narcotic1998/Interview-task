<template>
  <div class="card">
    <div class="container">
        <h2>Toll Management Application</h2> 
    </div>
  </div>  
</template>

<script>

export default {
  name: 'Header',
  
}
</script>
<style lang="scss" scoped>
.container {
  padding: 20px 16px;
  text-align: center;
}
.card {
  box-shadow: 2px 2px 4px 1px rgba(0,0,0,0.2);
  /* background-color: #f2f2f2; */
  color: teal;
  width: 100%;
  margin-top: 2px;
}
</style>